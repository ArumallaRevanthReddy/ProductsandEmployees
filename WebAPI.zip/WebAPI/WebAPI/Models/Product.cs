﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WebAPI.Models
{
    public partial class Product
    {
        public int ProductId { get; set; }
        public string Productname { get; set; }
        public string Category { get; set; }
        public int Createdby { get; set; }
        public DateTime Createdon { get; set; }
        public int Lastupdatedby { get; set; }
        public DateTime Lastupdatedon { get; set; }

        public virtual Employee CreatedbyNavigation { get; set; }
        public virtual Employee LastupdatedbyNavigation { get; set; }
    }
}
