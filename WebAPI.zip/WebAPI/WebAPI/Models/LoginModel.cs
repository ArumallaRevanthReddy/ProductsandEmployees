﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class LoginModel
    {
        public LoginModel(string email, string pwd)
        {
            Email = email;
            Pwd = pwd;
        }

        public string Email { get; set; }
        public string Pwd { get; set; }
    }
}
