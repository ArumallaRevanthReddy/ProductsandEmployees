﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class ChangePasswordModel
    {
        public int Id { get; set; }
        public string Oldpassword { get; set; }
        public string Newpassword { get; set; }

        public ChangePasswordModel(int id, string old, string nu)
        {
            this.Id = id;
            this.Oldpassword = old;
            this.Newpassword = nu;
        }
    }
}
