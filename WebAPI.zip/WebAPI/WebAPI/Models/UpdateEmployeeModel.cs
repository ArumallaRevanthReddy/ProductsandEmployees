﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class UpdateEmployeeModel
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }

        public string Email { get; set; }

        public UpdateEmployeeModel(int id, string Firstname, string Lastname, string Email)
        {
            this.Id = id;
            this.Firstname = Firstname;
            this.Lastname = Lastname;
            this.Email = Email;
        }
    }
}
