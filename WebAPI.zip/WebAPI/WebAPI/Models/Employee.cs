﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WebAPI.Models
{
    public partial class Employee
    {
        public Employee()
        {
            ProductCreatedbyNavigation = new HashSet<Product>();
            ProductLastupdatedbyNavigation = new HashSet<Product>();
        }

        public int UserId { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public bool IsAdmin { get; set; }
        public string Email { get; set; }
        public string Pwd { get; set; }

        public virtual ICollection<Product> ProductCreatedbyNavigation { get; set; }
        public virtual ICollection<Product> ProductLastupdatedbyNavigation { get; set; }
    }
}
