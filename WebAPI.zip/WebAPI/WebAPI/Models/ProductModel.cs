﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class ProductModel
    {
        public string Productname { get; set; }
        public string Category { get; set; }
        public ProductModel(string productname, string category)
        {
            Productname = productname;
            Category = category;
        }
    }
}
