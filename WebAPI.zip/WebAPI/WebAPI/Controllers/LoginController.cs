﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Security.Claims;
using System.Security.Principal;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[EnableCors("CORS")]
    public class LoginController : Controller
    {
        private IConfiguration _config;
        public LoginController(IConfiguration config)
        {
            _config = config;
        }

        [HttpGet]
        [Authorize]
        public string Get()
        {
            var currentUser = HttpContext.User;

            if (currentUser.HasClaim(c => c.Type == "Email"))
            {
                string email = currentUser.Claims.FirstOrDefault(c => c.Type == "Email").Value;
                return email;
            }
            return "no email claim";
        }

        [AllowAnonymous]
        [HttpPost]
        public IEnumerable<string> Post([FromBody] LoginModel model)
        {
            IActionResult response = Unauthorized();
            var user = AuthenticateUser(model);
            List<string> s = new List<string>();

            if (user != null)
            {
                var tokenString = GenerateJSONWebToken(user);
                response = Ok(new { token = tokenString });
                s.Add(tokenString);
                return s;
            }

            return null;
        }

        private string GenerateJSONWebToken(LoginModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            using (var context = new EmployeeDBContext())
            {
                Employee emp = context.Employee.Where(a => a.Email == userInfo.Email).FirstOrDefault();
                string isAdmin;
                if (emp.IsAdmin) { isAdmin = "yes"; }
                else isAdmin = "no";

                string id = emp.UserId.ToString();
                var claims = new[] {new Claim("IsAdmin", isAdmin),
                                new Claim("id", id),
                                new Claim("Email", userInfo.Email),
                                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())};

                var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                    _config["Jwt:Issuer"],
                    claims,
                    expires: DateTime.Now.AddMinutes(15),
                    signingCredentials: credentials);

                return new JwtSecurityTokenHandler().WriteToken(token);
            }
        }

        private LoginModel AuthenticateUser(LoginModel model)
        {

            using (var context = new EmployeeDBContext())
            {
                LoginModel user = new LoginModel(model.Email, model.Pwd);
                try
                {
                    Employee emp = context.Employee.Where(e => e.Email == model.Email).First();
                    if (emp.Pwd == model.Pwd) return user;
                    else return null;
                }
                catch
                {
                    return null;
                }
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [Route("valid")]
        public bool TokenValidation(string tokenString)
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            var arr = Payload(token);
            using (var context = new EmployeeDBContext())
            {
                try
                {
                    Employee emp = context.Employee.Where(e => e.Email == arr[1]).First();
                    if (emp != null) return true;
                    else return false;
                }
                catch
                {
                    return false;
                }
            }
        }

        private static TokenValidationParameters GetValidationParameters()
        {
            return new TokenValidationParameters()
            {
                ValidateLifetime = true,
                ValidateAudience = false,
                ValidateIssuer = true,
                ValidIssuer = "http://localhost:40557",
                ValidAudience = "*",
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("ThisismySecretKey"))
            };
        }


        public List<string> Payload(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jsonToken = handler.ReadToken(token);
            var tokenS = handler.ReadToken(token) as JwtSecurityToken;

            string id = tokenS.Claims.First(claim => claim.Type == "id").Value;
            string email = tokenS.Claims.First(claim => claim.Type == "Email").Value;
            string isAdmin = tokenS.Claims.First(claim => claim.Type == "IsAdmin").Value;
            string exp = tokenS.Claims.First(claim => claim.Type == "exp").Value;

            List<string> load = new List<string>();
            load.Add(id); load.Add(email); load.Add(isAdmin); load.Add(exp);
            return load;
        }
    }  

}

