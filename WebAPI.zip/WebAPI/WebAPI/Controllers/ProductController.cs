﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {

        [HttpGet]
        [AllowAnonymous]  /* original is [Authorize]*/
        public List<Product> Get()
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);
            List<Product> s = new List<Product>();

            using (var context = new EmployeeDBContext())
            {
                foreach (Product e in context.Product.ToList()) { s.Add(e); }
                return s;
            }
        }

        [Route("myproducts")]
        [HttpGet]
        public List<Product> GetMyProducts()
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);
            List<Product> s = new List<Product>();

            using (var context = new EmployeeDBContext())
            {

                if (arr[2] == "no")
                {
                    List<Product> a = context.Product.Where(p => p.Createdby == int.Parse(arr[0])).ToList();
                    foreach (Product e in a) { s.Add(e); }
                }
                else
                {
                    foreach (Product e in context.Product.ToList()) { s.Add(e); }
                }
                return s;
            }
        }


        [HttpPost]
        //[Authorize]
        public string Post([FromBody] ProductModel model)
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);
            int id = int.Parse(arr[0]);

            using (var context = new EmployeeDBContext())
            {
                try
                {
                    ProductModel pm = new ProductModel(model.Productname, model.Category);
                    Employee emp = context.Employee.Where(e => e.UserId == id).First();
                    Product p = new Product();
                    p.Productname = pm.Productname;
                    p.Category = pm.Category;
                    p.Createdby = emp.UserId;
                    p.Createdon = DateTime.Now;
                    p.Lastupdatedby = emp.UserId;
                    p.Lastupdatedon = DateTime.Now;
                    context.Product.Add(p);
                    context.SaveChanges();
                    return "product added succesfully";

                }
                catch
                {
                    return "failed to add product";
                }
            }
        }


        [HttpPut]
        //[Authorize]
        public string Put([FromBody] UpdateProductModel model)
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);
            int id = int.Parse(arr[0]);

            using (var context = new EmployeeDBContext())
            {
                try
                {
                    Employee emp = context.Employee.Where(e => e.UserId == id).FirstOrDefault();
                    Product p = context.Product.Where(p => p.Productname == model.Prev).First();
                    Product exis = context.Product.Where(p => p.Productname == model.Productname).First();
                    if(exis!= null) { return "product with the name already exists"; }
                    if (arr[2] == "yes" || p.Createdby == id)
                    {
                        p.Productname = model.Productname;
                        p.Category = model.Category;
                        p.Lastupdatedby = id;
                        p.Lastupdatedon = DateTime.Now;
                        context.Product.Update(p);
                        context.SaveChanges();
                        return "product updated succesfully";
                    }
                    else return "failed to update product data";
                }
                catch
                {
                    return "failed to update product error";
                }
            }
        }


        [HttpDelete]
        [Route("{productname}")]
        public string Delete(string productname)
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);
            int id = int.Parse(arr[0]);

            using (var context = new EmployeeDBContext())
            {
                try
                {
                    Employee emp = context.Employee.Where(e => e.UserId == id).FirstOrDefault();
                    Product p = context.Product.Where(p => p.Productname == productname).First();
                    if (arr[2] == "yes" || p.Createdby == id)
                    {
                        context.Product.Remove(p);
                        context.SaveChanges();
                        return "product deleted succesfully";
                    }

                    return "failed to delete product data";
                }
                catch
                {
                    return "failed to delete product error";
                }
            }
        }

        public List<string> Payload(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jsonToken = handler.ReadToken(token);
            var tokenS = handler.ReadToken(token) as JwtSecurityToken;

            string id = tokenS.Claims.First(claim => claim.Type == "id").Value;
            string email = tokenS.Claims.First(claim => claim.Type == "Email").Value;
            string isAdmin = tokenS.Claims.First(claim => claim.Type == "IsAdmin").Value;
            string exp = tokenS.Claims.First(claim => claim.Type == "exp").Value;

            List<string> load = new List<string>();
            load.Add(id); load.Add(email); load.Add(isAdmin); load.Add(exp);
            return load;
        }

    }

}

