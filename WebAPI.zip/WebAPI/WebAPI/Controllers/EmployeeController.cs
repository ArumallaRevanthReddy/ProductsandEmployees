﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using Microsoft.AspNetCore.Identity;
using System.Web.Providers.Entities;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[EnableCors("AllowOrigin")]
    public class EmployeeController : Controller
    {

        [HttpGet]
        //[Authorize]
        public List<Employee> Get()
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);

            List<Employee> s = new List<Employee>();

            using (var context= new EmployeeDBContext())
            {
                string email = arr[1];
                string isAdmin = arr[2]; 
                if (isAdmin == "yes")
                {
                    foreach (Employee e in context.Employee.ToList()) { s.Add(e); }
                    return s;
                }
                else
                {
                    return context.Employee.Where(emp => emp.Email == email).ToList();
                }
            }
        }


        [HttpPost]
        //[AllowAnonymous]
        public string Post([FromBody]Employee model)
        {
            using (var context = new EmployeeDBContext())
            {
                Employee e = context.Employee.Where(e => e.Email == model.Email).FirstOrDefault();
                if (e== null)
                {
                    try
                    {
                        Employee emp = new Employee();
                        emp.Firstname = model.Firstname;
                        emp.Lastname = model.Lastname;
                        emp.IsAdmin = model.IsAdmin;
                        emp.Email = model.Email;
                        emp.Pwd = model.Pwd;
                        context.Employee.Add(emp);
                        context.SaveChanges();
                        return "data added succesfully";
                    }
                    catch {return "failed to add data";}
                }
                else return "user already exists";  
            } 
        }


        [HttpPut]
        //[Authorize]
        public string Put([FromBody] UpdateEmployeeModel model)
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);
            int id = int.Parse(arr[0]);
            using (var context = new EmployeeDBContext())
            {
                try
                {
                    Employee emp = context.Employee.Where(e => e.UserId == model.Id).First();
                    emp.UserId = model.Id;
                    emp.Firstname = model.Firstname;
                    emp.Lastname = model.Lastname;
                    emp.Email = model.Email;
                    context.Employee.Update(emp);
                    context.SaveChanges();
                    return "user data updated succesfully";
                }
                catch
                {
                    return "failed to update user data";
                }
            }
        }

        
        [HttpPut]
        [Route("changepassword")]
        public string ChangePassword([FromBody] ChangePasswordModel model)
        {
            string token = HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            List<string> arr = Payload(token);
            int id = int.Parse(arr[0]);
            using (var context = new EmployeeDBContext())
            {
                Employee emp = context.Employee.Where(e => e.UserId == model.Id).First();
                try
                {
                    if (arr[2] == "yes")
                    {
                        Employee admin = context.Employee.Where(e => e.UserId == id).First();
                        if (admin.Pwd == model.Oldpassword)
                        {
                            emp.Pwd = model.Newpassword;
                            context.Employee.Update(emp);
                            context.SaveChanges();
                            return "password changed succesfully";
                        }
                        else return "failed to change password";
                    }

                    if(emp.Pwd == model.Oldpassword)
                    {
                        emp.Pwd = model.Newpassword;
                        context.Employee.Update(emp);
                        context.SaveChanges();
                        return "password changed succesfully";
                    }
                    else return "wrong existing password";
                }
                catch
                {
                    return "failed to change password error";
                }
            }
        }


        /*[HttpDelete]
        [Authorize]
        public string Delete(string email)
        {
            using (var context = new EmployeeDBContext())
            {
                try
                {
                    Employee emp = context.Employee.Where(e => e.Email == email).First();
                    emp.Email = email;
                    context.Employee.Remove(emp);
                    context.SaveChanges();
                    return "data deleted succesfully";
                }
                catch {return "failed to delete data";}
            }
        }*/

        public List<string> Payload(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jsonToken = handler.ReadToken(token);
            var tokenS = handler.ReadToken(token) as JwtSecurityToken;

            string id = tokenS.Claims.First(claim => claim.Type == "id").Value;
            string email = tokenS.Claims.First(claim => claim.Type == "Email").Value;
            string isAdmin = tokenS.Claims.First(claim => claim.Type == "IsAdmin").Value;
            string exp = tokenS.Claims.First(claim => claim.Type == "exp").Value;

            List<string> load = new List<string>();
            load.Add(id); load.Add(email); load.Add(isAdmin); load.Add(exp);
            return load;
        }

    }
}
